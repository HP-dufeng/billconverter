package Tools

interface IDataExtractor {
    fun extract() : Map<String, String>
}