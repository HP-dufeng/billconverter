interface IFileGen {
    fun genBalanceFile(sourceRT: String, DestinationRT: String)
    fun genPosFile(sourceRT: String, DestinationRT: String)
    fun genTradeFile(sourceRT: String, DestinationRT: String)
}