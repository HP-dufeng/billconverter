/**
 * version 0.8 by Edwin
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;

import com.csvreader.*;

class FileGen {
    public static void main(String[] arguments) {

        String ZDFile;
        if (arguments.length != 0) {
            ZDFile = "src/" + arguments[0] + ".txt";
        } else {
            ZDFile = "sample/611888.txt";
        }
        String DesRT = "dst/";
        FileGen fileGen = new FileGen();
        fileGen.genBalanceFile(ZDFile, DesRT);
        fileGen.genPosFile(ZDFile, DesRT);
        fileGen.genTradeFile(ZDFile, DesRT);

        System.out.println(new Date() + " File generation completes! ");


    }

    public String subTypeConv(String st) {
        if (st.equals("O")) {
            return "P";
        } else if (st.equals("C") || st.equals("CT")) {
            return "C";
        } else {
            return null;
        }
    }

    public String buySellConv(String bs) {
        if (bs.equals("B")) {
            return "1";
        } else if (bs.equals("S")) {
            return "0";
        } else {
            return null;
        }
    }

    /**
     * 月份转换
     *
     * @param month
     * @return
     */
    public String monthConv(String month) {
        // 2017年12月19日13:45:09 by yitian.chen
        return month;
    }

    public String getZDDate(String sourceRT) {
        //Extract ZD date
        String tmp;
        String ZDDate = null;
        String ZDFile = sourceRT;
        File f = new File(ZDFile);
        try {
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String s = br.readLine();
            tmp = "DATE:";

            int num;
            while (s != null) {
                num = s.indexOf(tmp);
                if (num != -1) {
                    String str = null;
                    try {
                        str = s.substring(num + tmp.length());
                        str = str.trim();
                        num = str.indexOf(" ");
                        if (num != -1) {
                            str = str.substring(0, num);
                        }

                        str.trim();
                    } catch (Exception e) {
                        System.out.println(new Date() + " Error:" + e.getMessage());
                        e.printStackTrace();
                    }
                    ZDDate = str;// 这个就应该是你要的东西了
                    break;
                }
                s = br.readLine();
            }
            br.close();// 关闭缓冲读入流及文件读入流的连接.
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ZDDate;

    }


    private void genBalanceFile(String sourceRT, String DestinationRT) {


        //Extract ZD date
        String tmp = null;
        String ZDDate = this.getZDDate(sourceRT);
        File f = new File(sourceRT);

        String directory = DestinationRT;
        String FNameForBalance = "WANDA_SHBalances_" + ZDDate + "_" + new Time().getUTCStr() + ".csv";

        String[] contentForBalance = {"Account", "Currency", "BalanceBf", "Deposit", "Withdrawal", "OptionPremium", "DeliveryProceed", "RealisedPL", "Commission", "Interest", "Others", "BalanceCf", "UnrealisedPL", "Equity", "NetOptionValue", "EligCollateral", "as-of-date\nmm/dd/yyyy"};

        CsvWriter wrBalance = new CsvWriter(directory + FNameForBalance, ',', Charset.forName("GBK"));

        String account = null;
        String Currency = "CNY";
        String BalanceBf = null;
        String Deposit = null;
        String Withdrawal = null;
        String OptionPremium = "";
        String DeliveryProceed = "";
        String RealisedPL = null;
        String Commission = null;
        String Interest = "";
        String Others = "";
        String BalanceCf = null;
        String UnrealisedPL = null;
        String Equity = null;
        String NetOptionValue = "";
        String EligCollateral = "";
        String as_of_date = ZDDate.substring(4, 6) + "/" + ZDDate.substring(6, 8) + "/" + ZDDate.substring(0, 4);

        //account
        account = getByToken(f, "CLIENT NO.:");
        //BalanceBf
        account = getByToken(f, "BEGINNING BALANCE:");
        //Deposit  //Withdrawal
        String tmpValue = getByToken(f, "DEPOSIT/WITHDRAWAL:");
        if (Float.parseFloat(tmpValue) >= 0) {
            Deposit = tmpValue;
            Withdrawal = "0";
        } else {
            Deposit = "0";
            Withdrawal = tmpValue.substring(1);
        }
        //RealisedPL
        RealisedPL = getByToken(f, "REALISED P/L:");
        //Commission
        Commission = getByToken(f, "FEES:");
        //BalanceCf
        BalanceCf = getByToken(f, "ENDING BALANCE:");
        //UnrealisedPL
        UnrealisedPL = getByToken(f, "FLOATING P/L:");
        //Equity
        Equity = getByToken(f, "TOTAL EQUITY:");

        String[] balanceRec = {account, Currency, BalanceBf, Deposit, Withdrawal, OptionPremium, DeliveryProceed, RealisedPL, Commission, Interest, Others, BalanceCf, UnrealisedPL, Equity, NetOptionValue, EligCollateral, as_of_date};

        try {

            wrBalance.writeRecord(contentForBalance);
            wrBalance.writeRecord(balanceRec);
            wrBalance.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void genPosFile(String sourceRT, String DestinationRT) {


        //Extract ZD date
        String tmp;
        String ZDDate = this.getZDDate(sourceRT);
        File f = new File(sourceRT);

        int mark = 0;
        String directory = DestinationRT;
        String FNameForPos = "WANDA_SHPos_" + ZDDate + "_" + new Time().getUTCStr() + ".csv";

        String[] contentForPos = {"Account", "Tradedate", "Long", "Short", "FutOpt", "Exchange", "Contract", "ContractMonth", "Contractyear", "StrikePrice", "Price", "SettPrice", "Currency", "UnrealisedPL", "TradeNo", "BUY/Sell\n1=BUY\n0=SELL\n", "SubType\nP=Put\nC=Call", "Commodity", "Commission", "Option Delta", "Firm/Office", "as-of-date\n(mm/dd/yyyy)"};

        CsvWriter wrPos = new CsvWriter(directory + FNameForPos, ',', Charset.forName("GBK"));
        try {
            wrPos.writeRecord(contentForPos);
        } catch (IOException e) {
            System.out.println(new Date() + " Error:" + e.getMessage());
            e.printStackTrace();
        }


        String account = null;
        String Tradedate = ZDDate.substring(4, 6) + "/" + ZDDate.substring(6, 8) + "/" + ZDDate.substring(0, 4);
        String Long;
        String Short;
        String FutOpt = "F";
        String Exchange;
        String Contract;
        String ContractMonth;
        String Contractyear;
        String StrikePrice = "";
        String Price = null;
        String SettPrice;
        String Currency = "CNY";
        String UnrealisedPL;
        String TradeNo = "";
        String BUY_Sell = "";
        String SubType = "";
        String Commodity;
        String Commission = "";
        String Option_Delta = "";
        String Firm = "Shanghai Bunge";
        String as_of_date = ZDDate.substring(4, 6) + "/" + ZDDate.substring(6, 8) + "/" + ZDDate.substring(0, 4);


        //account
        account = getByToken(f, "CLIENT NO.:");

        //Long  //short
        try {
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String s = br.readLine();
            tmp = "OPEN POSITIONS SUMMARY";

            int num;
            while (s != null) {
                num = s.indexOf(tmp);
                if (num >= 0) {
                    String str;
                    try {
                        str = s.substring(num + tmp.length());
                        str = str.trim();
                        num = str.indexOf(" ");
                        if (num != -1) {
                            str = str.substring(0, num);
                        }
                        str.trim();
                    } catch (Exception e) {
                        System.out.println(new Date() + " Error:" + e.getMessage());
                        e.printStackTrace();
                    }
                    mark = 1;
                    break;
                }
                s = br.readLine();
            }
            if (mark == 0) {
                br.close();
                return;
            }
            for (int i = 0; i < 3; i++) {
                s = br.readLine();
            }
            while (s.indexOf("TOTAL:") == -1) {
                if(s.indexOf(" ") == -1) {
                    break;
                }

                Exchange = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                Commodity = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                Contract = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                ContractMonth = this.monthConv(Contract.substring(Contract.length() - 2));
                Contractyear = "20" + Contract.substring(Contract.length() - 4, Contract.length() - 2);

                Long = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                if (Long.equals("0")) {
                    s = s.substring(s.indexOf(" ")).trim();
                } else {
                    Price = s.substring(0, s.indexOf(" ")).trim();
                    s = s.substring(s.indexOf(" ")).trim();
                }

                Short = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                if (Short.equals("0")) {
                    s = s.substring(s.indexOf(" ")).trim();
                } else {
                    Price = s.substring(0, s.indexOf(" ")).trim();
                    s = s.substring(s.indexOf(" ")).trim();
                }

                s = s.substring(s.indexOf(" ")).trim();

                SettPrice = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                UnrealisedPL = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                String[] posRec = {account, Tradedate, Long, Short, FutOpt, Exchange, Contract, ContractMonth, Contractyear, StrikePrice, Price, SettPrice, Currency, UnrealisedPL, TradeNo, BUY_Sell, SubType, Commodity, Commission, Option_Delta, Firm, as_of_date};
                wrPos.writeRecord(posRec);

                for (int i = 0; i < 2; i++) {
                    s = br.readLine();
                }
            }
            br.close();// 关闭缓冲读入流及文件读入流的连接.
        } catch (Exception e) {
            e.printStackTrace();
        }
        wrPos.close();
    }

    public void genTradeFile(String sourceRT, String DestinationRT) {


        //Extract ZD date
        String tmp = null;
        String ZDDate = this.getZDDate(sourceRT);
        File f = new File(sourceRT);
        int mark = 0;

        String directory = DestinationRT;
        String FNameForTrade = "WANDA_SHTrades_" + ZDDate + "_" + new Time().getUTCStr() + ".csv";

        String[] contentForTrade = {"Account", "Tradedate", "Long", "Short", "FutOpt", "Exchange", "Contract", "ContractMonth", "Contractyear", "StrikePrice", "Price", "SettPrice", "Currency", "UnrealisedPL", "TradeNo", "BUY/Sell\n1=BUY\n0=SELL\n", "SubType\nP=Put\nC=Call", "Commodity", "Commission", "Option Delta", "Firm/Office", "as-of-date\n(mm/dd/yyyy)"};

        CsvWriter wrTrade = new CsvWriter(directory + FNameForTrade, ',', Charset.forName("GBK"));
        try {
            wrTrade.writeRecord(contentForTrade);
        } catch (IOException e) {
            System.out.println(new Date() + " Error:" + e.getMessage());
            e.printStackTrace();
        }


        String account = null;
        String tradedate = ZDDate.substring(4, 6) + "/" + ZDDate.substring(6, 8) + "/" + ZDDate.substring(0, 4);
        String Long;
        String Short;
        String FutOpt = "F";
        String Exchange;
        String Contract;
        String ContractMonth;
        String contractyear;
        String StrikePrice = "";
        String Price;
        String SettPrice = "";
        String Currency = "CNY";
        String UnrealisedPL = "";
        String TradeNo = "";
        String BUY_Sell;
        String SubType = "";
        String Commodity;
        String Commission;
        String Option_Delta = "";
        String Firm = "Shanghai Bunge";
        String as_of_date = ZDDate.substring(4, 6) + "/" + ZDDate.substring(6, 8) + "/" + ZDDate.substring(0, 4);


        //account
        try {
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String s = br.readLine();
            tmp = "CLIENT NO.:";

            int num;
            while (s != null) {
                num = s.indexOf(tmp);
                if (num != -1) {
                    String str = null;
                    try {
                        str = s.substring(num + tmp.length());
                        str = str.trim();
                        num = str.indexOf(" ");
                        if (num != -1) {
                            str = str.substring(0, num);
                        }
                        str.trim();
                    } catch (Exception e) {
                        System.out.println(new Date() + " Error:" + e.getMessage());
                        e.printStackTrace();
                    }
                    account = str;// 这个就应该是你要的东西了
                    break;
                }
                s = br.readLine();
            }
            br.close();// 关闭缓冲读入流及文件读入流的连接.
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Long  //short
        try {
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String s = br.readLine();
            tmp = "TRADE CONFIRMATION";

            int num;
            while (s != null) {
                num = s.indexOf(tmp);
                if (num != -1) {
                    String str;
                    try {
                        str = s.substring(num + tmp.length());
                        str = str.trim();
                        num = str.indexOf(" ");
                        if (num != -1) {
                            str = str.substring(0, num);
                        }
                        str.trim();
                    } catch (Exception e) {
                        System.out.println(new Date() + " Error:" + e.getMessage());
                        e.printStackTrace();
                    }
                    mark = 1;
                    break;
                }
                s = br.readLine();
            }

            if (mark == 0) {
                wrTrade.close();
                br.close();
                return;
            }

            for (int i = 0; i < 6; i++) {
                s = br.readLine();
            }
            while (s.indexOf("TOTAL:") == -1) {

                if (s.indexOf(" ") == -1) {
                    break;
                }

                s = s.substring(s.indexOf(" ")).trim();

                Exchange = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                Commodity = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                Contract = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                ContractMonth = this.monthConv(Contract.substring(Contract.length() - 2));
                contractyear = "20" + Contract.substring(Contract.length() - 4, Contract.length() - 2);

                BUY_Sell = this.buySellConv(s.substring(0, s.indexOf(" ")).trim());
                s = s.substring(s.indexOf(" ")).trim();

                Price = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                if (BUY_Sell.equals("1")) {
                    Long = s.substring(0, s.indexOf(" ")).trim();
                    Short = "0";
                    s = s.substring(s.indexOf(" ")).trim();
                } else {
                    Long = "0";
                    Short = s.substring(0, s.indexOf(" ")).trim();
                    s = s.substring(s.indexOf(" ")).trim();
                }

                s = s.substring(s.indexOf(" ")).trim();


                s = s.substring(s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();

                Commission = s.substring(0, s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();


                String[] tradeRec = {account, tradedate, Long, Short, FutOpt, Exchange, Contract, ContractMonth, contractyear, StrikePrice, Price, SettPrice, Currency, UnrealisedPL, TradeNo, BUY_Sell, SubType, Commodity, Commission, Option_Delta, Firm, as_of_date};
                wrTrade.writeRecord(tradeRec);


                for (int i = 0; i < 2; i++) {
                    s = br.readLine();
                }
            }
            br.close();// 关闭缓冲读入流及文件读入流的连接.
        } catch (Exception e) {
            e.printStackTrace();
        }
        wrTrade.close();
    }

    /**
     * 从文件中获取某个Token的值
     *
     * @param file
     * @param token
     * @return
     */
    private String getByToken(File file, String token) {
        String value = null;
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String s = br.readLine();

            int num;
            while (s != null) {
                num = s.indexOf(token);
                if (num != -1) {
                    String str = null;
                    try {
                        str = s.substring(num + token.length());
                        str = str.trim();
                        num = str.indexOf(" ");
                        if (num != -1) {
                            str = str.substring(0, num);
                        }
                        str.trim();
                    } catch (Exception e) {
                        System.out.println(new Date() + " Error:" + e.getMessage());
                        e.printStackTrace();
                    }
                    value = str;// 这个就应该是你要的东西了
                    break;
                }
                s = br.readLine();
            }
            br.close();// 关闭缓冲读入流及文件读入流的连接.
        } catch (Exception e) {
            e.printStackTrace();
        }

        return value;
    }
}